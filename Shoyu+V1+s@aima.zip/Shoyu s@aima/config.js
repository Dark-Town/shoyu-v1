const global = {
    owner: [6142885267], // ganti jadi id mu
    botToken: "7725260979:AAF9pls5ef2mKp0eZu-djXeFnnwC5XCRyL8", //isi make token bot mu
}

module.exports = global;